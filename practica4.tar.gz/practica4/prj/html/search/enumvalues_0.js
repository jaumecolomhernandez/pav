var searchData=
[
  ['dir',['DIR',['../classupc_1_1FileInfo.html#a0d92d84fa1bd96c5e623e696ef484f38aaa05780e3df0257e7affc677909e2e2f',1,'upc::FileInfo']]]
];
