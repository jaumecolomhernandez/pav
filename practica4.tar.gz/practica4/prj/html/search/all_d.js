var searchData=
[
  ['n',['N',['../test__fft_8cpp.html#a0240ac851181b84ac374872dc5434ee4',1,'N():&#160;test_fft.cpp'],['../FFTReal__readme_8txt.html#a049dd452c22185832440207517cffdaa',1,'N():&#160;FFTReal_readme.txt']]],
  ['ncol',['ncol',['../classupc_1_1matrix.html#a0e8f41d88948610215db9cc8eafa02a6',1,'upc::matrix']]],
  ['nl',['NL',['../namespaceupc_1_1ascii.html#a8c3d9f1660792c0a53398e5cc64f4bcf',1,'upc::ascii']]],
  ['npitch_5fmax',['npitch_max',['../classupc_1_1PitchAnalyzer.html#a63d4cf285fa5f7a4e579ac2e02d36dd2',1,'upc::PitchAnalyzer']]],
  ['npitch_5fmin',['npitch_min',['../classupc_1_1PitchAnalyzer.html#a3bb67370dbd69fade6be12fdae510eed',1,'upc::PitchAnalyzer']]],
  ['nrow',['nrow',['../classupc_1_1matrix.html#a7b922be25c0cf0d255252a4fe7350ea2',1,'upc::matrix']]]
];
