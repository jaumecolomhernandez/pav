var searchData=
[
  ['f',['f',['../FFTReal__readme_8txt.html#abbf3cc73d1e3e4714ab1639819396eca',1,'FFTReal_readme.txt']]],
  ['ff',['FF',['../namespaceupc_1_1ascii.html#af5ddbbb8830f0005861ff0a7c859c062',1,'upc::ascii']]],
  ['fftreal',['FFTReal',['../FFTReal__readme_8txt.html#afc545541c7ab0be25cf239418fc47b65',1,'FFTReal_readme.txt']]],
  ['float',['float',['../FFTReal__readme_8txt.html#a0ea2fae2a8106200bf378b90eae003cf',1,'FFTReal_readme.txt']]],
  ['frame_5flength',['frame_length',['../structVAD__DATA.html#a24ae8d2d4e2c13f0c930cb281ddf5ae5',1,'VAD_DATA']]],
  ['frame_5ftime',['FRAME_TIME',['../vad_8c.html#ae3a41f505fa8d010bea4cb6d61a9019d',1,'vad.c']]],
  ['framelen',['frameLen',['../classupc_1_1PitchAnalyzer.html#a6ef737140140ec94f7be345804f28c73',1,'upc::PitchAnalyzer']]]
];
