var searchData=
[
  ['last_5ffeature',['last_feature',['../structVAD__DATA.html#a73be3c4f2bddba51db3f74d1df7b9286',1,'VAD_DATA']]],
  ['lf',['LF',['../namespaceupc_1_1ascii.html#a628dd589ffd58739bc253012809d38fb',1,'upc::ascii']]]
];
