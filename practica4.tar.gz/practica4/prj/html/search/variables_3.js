var searchData=
[
  ['calculations',['calculations',['../FFTReal__readme_8txt.html#a65cbf8e61482778d7aa2ebe890cc7d7c',1,'FFTReal_readme.txt']]],
  ['class',['class',['../FFTReal__readme_8txt.html#ad229ab5c8241df85a2096743cc8c4e9f',1,'FFTReal_readme.txt']]],
  ['cr',['CR',['../namespaceupc_1_1ascii.html#a9cd56052c84609b89d09985a4651c436',1,'upc::ascii']]]
];
