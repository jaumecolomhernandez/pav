var searchData=
[
  ['set',['set',['../classupc_1_1KeyValue.html#aff88fb11aa97cd85fa0b398e34ed763a',1,'upc::KeyValue']]],
  ['set_5fa',['set_a',['../classupc_1_1DigitalFilter.html#ade3c3a24bbfbc1b2edbf4bcd0885a9e6',1,'upc::DigitalFilter']]],
  ['set_5fb',['set_b',['../classupc_1_1DigitalFilter.html#a9f23a5e9db027eb0c9b70bd9b5d08e09',1,'upc::DigitalFilter']]],
  ['set_5ff0_5frange',['set_f0_range',['../classupc_1_1PitchAnalyzer.html#ac33887654b62b3f90c3de231ec187d94',1,'upc::PitchAnalyzer']]],
  ['set_5fgain',['set_gain',['../classupc_1_1DigitalFilter.html#a506905346c44ac46c292ea1fa1212c3e',1,'upc::DigitalFilter']]],
  ['set_5fresonator',['set_resonator',['../classupc_1_1DigitalFilter.html#a2b97aaeacac8b5a8b52e1bd8fc295970',1,'upc::DigitalFilter']]],
  ['set_5fstep',['set_step',['../classffft_1_1OscSinCos.html#ad41139a76b16a5af136d1e730a9143dc',1,'ffft::OscSinCos']]],
  ['set_5fwindow',['set_window',['../classupc_1_1PitchAnalyzer.html#a96cc042a650825b25ca39c41beebd0db',1,'upc::PitchAnalyzer']]],
  ['sfreqz',['sfreqz',['../classupc_1_1DigitalFilter.html#a9589b9615fbd51754afb757c5431b1e0',1,'upc::DigitalFilter']]],
  ['size',['size',['../classffft_1_1DynArray.html#aab5a878741b62b079c94db354357127d',1,'ffft::DynArray::size()'],['../classupc_1_1FileInfo.html#a312ce236409905ae3b0ebaa0c441511c',1,'upc::FileInfo::size()'],['../classupc_1_1Filename.html#a232b2a742810eb8f213644cd367c8905',1,'upc::Filename::size()']]],
  ['state2str',['state2str',['../vad_8h.html#afa50d0be16dbf537eef6fc5d2cedd64f',1,'state2str(VAD_STATE st):&#160;vad.c'],['../vad_8c.html#afa50d0be16dbf537eef6fc5d2cedd64f',1,'state2str(VAD_STATE st):&#160;vad.c']]],
  ['step',['step',['../classffft_1_1OscSinCos.html#a442975ce6388271ea78998c080364e08',1,'ffft::OscSinCos']]]
];
