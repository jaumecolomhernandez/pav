var searchData=
[
  ['hamming',['HAMMING',['../classupc_1_1PitchAnalyzer.html#ab82b7694d6bc72839e5be6e526be81b6a20e793e736a503aacbed0294970a9b33',1,'upc::PitchAnalyzer']]]
];
