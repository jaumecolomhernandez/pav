var searchData=
[
  ['array',['array',['../classupc_1_1array.html',1,'upc']]],
  ['array_3c_20_5ftptr_20_3e',['array&lt; _Tptr &gt;',['../classupc_1_1array.html',1,'upc']]]
];
