var searchData=
[
  ['ascii',['ascii',['../namespaceupc_1_1ascii.html',1,'upc']]],
  ['u',['u',['../classupc_1_1DigitalFilter.html#ad8b8d1c7bde2fca050aa297b66d69179',1,'upc::DigitalFilter']]],
  ['unvoiced',['unvoiced',['../classupc_1_1PitchAnalyzer.html#a0b32960107336078d87118cb10d6c83f',1,'upc::PitchAnalyzer']]],
  ['upc',['upc',['../namespaceupc.html',1,'']]],
  ['use_5fbuffer',['use_buffer',['../classffft_1_1FFTReal.html#af1fcd007f1cf0b41bd2188e0b3cd5cca',1,'ffft::FFTReal']]]
];
