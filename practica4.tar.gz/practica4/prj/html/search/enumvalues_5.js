var searchData=
[
  ['st_5finit',['ST_INIT',['../vad_8h.html#a655a5d992101d81e27b861d90c712d65ad7fd527e9b09b1822fbee87683a69937',1,'vad.h']]],
  ['st_5fmaybesilence',['ST_MAYBESILENCE',['../vad_8h.html#a655a5d992101d81e27b861d90c712d65ad1bcb3f7c22ab100230b84a3125e2c54',1,'vad.h']]],
  ['st_5fmaybevoice',['ST_MAYBEVOICE',['../vad_8h.html#a655a5d992101d81e27b861d90c712d65af48bcec351e426efeba63dd80d896b38',1,'vad.h']]],
  ['st_5fsilence',['ST_SILENCE',['../vad_8h.html#a655a5d992101d81e27b861d90c712d65a2a5c7ca66a2124e9bc80843608a1d96b',1,'vad.h']]],
  ['st_5fundef',['ST_UNDEF',['../vad_8h.html#a655a5d992101d81e27b861d90c712d65a1304275ad7093093032465cc2be35974',1,'vad.h']]],
  ['st_5fvoice',['ST_VOICE',['../vad_8h.html#a655a5d992101d81e27b861d90c712d65acf8e29e294dcf56289fbc382c5fc473c',1,'vad.h']]]
];
