var searchData=
[
  ['a',['a',['../classupc_1_1DigitalFilter.html#a2452cdde3d6845b838d9ebed8099dc4e',1,'upc::DigitalFilter']]],
  ['am',['am',['../structFeatures.html#a767255b0011e02ba7edc937e69805dd4',1,'Features']]],
  ['apply_5fwindow',['apply_window',['../pav__analysis_8h.html#a9355b082f07b908316d6d2e5270bd495',1,'apply_window(float *x, float *w, float *x_windowed, unsigned int N):&#160;pav_analysis.c'],['../pav__analysis_8c.html#a9355b082f07b908316d6d2e5270bd495',1,'apply_window(float *x, float *w, float *x_windowed, unsigned int N):&#160;pav_analysis.c']]],
  ['array',['array',['../classupc_1_1array.html#a91a96a5d4ba2076aa8d221916d8376a2',1,'upc::array']]],
  ['array',['array',['../classupc_1_1array.html',1,'upc']]],
  ['array_3c_20_5ftptr_20_3e',['array&lt; _Tptr &gt;',['../classupc_1_1array.html',1,'upc']]],
  ['autocorrelation',['autocorrelation',['../classupc_1_1PitchAnalyzer.html#a45da4fa8b3d7bd67d87468a3153a839e',1,'upc::PitchAnalyzer']]]
];
