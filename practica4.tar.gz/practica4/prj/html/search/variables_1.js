var searchData=
[
  ['a',['a',['../classupc_1_1DigitalFilter.html#a2452cdde3d6845b838d9ebed8099dc4e',1,'upc::DigitalFilter']]],
  ['am',['am',['../structFeatures.html#a767255b0011e02ba7edc937e69805dd4',1,'Features']]]
];
