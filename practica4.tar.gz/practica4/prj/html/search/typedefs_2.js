var searchData=
[
  ['datatype',['DataType',['../classffft_1_1DynArray.html#aa21fa88c73e511acb18a7e778190ab02',1,'ffft::DynArray::DataType()'],['../classffft_1_1FFTReal.html#a606148f1cf8c3b7d705473932fc063d1',1,'ffft::FFTReal::DataType()'],['../classffft_1_1OscSinCos.html#af91237051e92ce0af7aaf38b1826244d',1,'ffft::OscSinCos::DataType()']]],
  ['dmatrix',['dmatrix',['../namespaceupc.html#a53f2db863d6ef79ba43159171dce9612',1,'upc']]],
  ['dvector',['dvector',['../namespaceupc.html#a226c72b20137fbf8cc10b0c0ca887b5d',1,'upc']]]
];
