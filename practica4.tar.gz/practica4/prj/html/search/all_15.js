var searchData=
[
  ['wavfile_5fmono_2ecpp',['wavfile_mono.cpp',['../wavfile__mono_8cpp.html',1,'']]],
  ['wavfile_5fmono_2eh',['wavfile_mono.h',['../wavfile__mono_8h.html',1,'']]],
  ['window',['window',['../classupc_1_1PitchAnalyzer.html#aa9531a6af11904dca47a18cc22c4bcdd',1,'upc::PitchAnalyzer::window()'],['../classupc_1_1PitchAnalyzer.html#ab82b7694d6bc72839e5be6e526be81b6',1,'upc::PitchAnalyzer::Window()']]],
  ['writewav_5fmono',['writewav_mono',['../wavfile__mono_8h.html#a43d41231f7fb07149e00c477727a8254',1,'writewav_mono(const std::string &amp;filename, unsigned int sampling_freq, const std::vector&lt; float &gt; &amp;x):&#160;wavfile_mono.h'],['../wavfile__mono_8cpp.html#a044fc29ca8222e16e340036e9b28c0e8',1,'writewav_mono(const string &amp;filename, unsigned int sampling_freq, const vector&lt; float &gt; &amp;x):&#160;wavfile_mono.cpp']]]
];
