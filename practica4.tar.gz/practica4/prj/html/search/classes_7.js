var searchData=
[
  ['oscsincos',['OscSinCos',['../classffft_1_1OscSinCos.html',1,'ffft']]]
];
