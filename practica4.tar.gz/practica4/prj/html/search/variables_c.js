var searchData=
[
  ['n',['N',['../FFTReal__readme_8txt.html#a049dd452c22185832440207517cffdaa',1,'FFTReal_readme.txt']]],
  ['nl',['NL',['../namespaceupc_1_1ascii.html#a8c3d9f1660792c0a53398e5cc64f4bcf',1,'upc::ascii']]],
  ['npitch_5fmax',['npitch_max',['../classupc_1_1PitchAnalyzer.html#a63d4cf285fa5f7a4e579ac2e02d36dd2',1,'upc::PitchAnalyzer']]],
  ['npitch_5fmin',['npitch_min',['../classupc_1_1PitchAnalyzer.html#a3bb67370dbd69fade6be12fdae510eed',1,'upc::PitchAnalyzer']]]
];
