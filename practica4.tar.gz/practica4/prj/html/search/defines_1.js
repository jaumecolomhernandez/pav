var searchData=
[
  ['debug_5fvad',['DEBUG_VAD',['../main__vad_8c.html#ada6204163b0b4cff6d248aaa88837230',1,'main_vad.c']]]
];
