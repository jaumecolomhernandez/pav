var searchData=
[
  ['read_5fvector',['read_vector',['../pitch__evaluate_8cpp.html#acc47b8492bcbc1ad3fab7d6ac74d2d8d',1,'pitch_evaluate.cpp']]],
  ['readwav_5fmono',['readwav_mono',['../wavfile__mono_8h.html#aedcb767fa59813d39dc5cd862faa793b',1,'readwav_mono(const std::string &amp;filename, unsigned int &amp;sampling_rate, std::vector&lt; float &gt; &amp;x):&#160;wavfile_mono.h'],['../wavfile__mono_8cpp.html#a4520ce28d4225a186fbdc50ba39221b9',1,'readwav_mono(const string &amp;filename, unsigned int &amp;sampling_freq, vector&lt; float &gt; &amp;x):&#160;wavfile_mono.cpp']]],
  ['rescale',['rescale',['../classffft_1_1FFTReal.html#a9e30fff775905b1059aa9299004ee228',1,'ffft::FFTReal::rescale()'],['../FFTReal__readme_8txt.html#ab87096300f2c26c87aa35b0623fdfd1e',1,'rescale():&#160;FFTReal_readme.txt']]],
  ['reset',['reset',['../classupc_1_1array.html#aeb72a62336fc9474afdf3fa6f5cea9ca',1,'upc::array::reset()'],['../classupc_1_1matrix.html#aec394dcccbfaad5c75a013874814c475',1,'upc::matrix::reset()']]],
  ['resize',['resize',['../classupc_1_1CircularIndex.html#aa8bfc28723ab87c1ab66262843aac2a5',1,'upc::CircularIndex::resize()'],['../classffft_1_1DynArray.html#a3879167bca7e35ee75596318f67e2930',1,'ffft::DynArray::resize()'],['../classupc_1_1matrix.html#ad9c957658ec403494af0d92fa2c499fb',1,'upc::matrix::resize()']]]
];
