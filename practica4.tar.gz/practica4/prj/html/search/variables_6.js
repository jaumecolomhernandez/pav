var searchData=
[
  ['gain',['gain',['../classupc_1_1DigitalFilter.html#aaa94a0d08f87c98612d9471719bd773a',1,'upc::DigitalFilter']]],
  ['gross_5fthreshold',['gross_threshold',['../pitch__evaluate_8cpp.html#ac3e1e3eb989b9766a74a68f946c1b20d',1,'pitch_evaluate.cpp']]]
];
