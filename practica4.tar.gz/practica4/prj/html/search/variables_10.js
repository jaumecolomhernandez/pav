var searchData=
[
  ['sampling_5frate',['sampling_rate',['../structVAD__DATA.html#ad2b4da91b7353a41a0fe64e65093e056',1,'VAD_DATA']]],
  ['samplingfreq',['samplingFreq',['../classupc_1_1PitchAnalyzer.html#a92578165c78c763749ef5c8aa23b1ca2',1,'upc::PitchAnalyzer']]],
  ['size',['size',['../classupc_1_1CircularIndex.html#ab53d382eeb825c3583964729c477ffae',1,'upc::CircularIndex']]],
  ['speaking',['speaking',['../FFTReal__readme_8txt.html#a2c9b06685d7b48b69727762751de915d',1,'FFTReal_readme.txt']]],
  ['sqrt2',['SQRT2',['../namespaceffft.html#a489004390ad7d791bf53a724c0f07abb',1,'ffft']]],
  ['state',['state',['../structVAD__DATA.html#a02d71db9de6c2438820ea1cfab9187bf',1,'VAD_DATA']]],
  ['state_5fstr',['state_str',['../vad_8c.html#a3012714639dac6ee77ac759f561c8702',1,'vad.c']]]
];
