var searchData=
[
  ['ascii',['ascii',['../namespaceupc_1_1ascii.html',1,'upc']]],
  ['upc',['upc',['../namespaceupc.html',1,'']]]
];
