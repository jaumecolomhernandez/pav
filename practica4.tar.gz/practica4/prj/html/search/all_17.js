var searchData=
[
  ['zcr',['zcr',['../structFeatures.html#a02006441e52641420bcac6b7adffc660',1,'Features']]]
];
