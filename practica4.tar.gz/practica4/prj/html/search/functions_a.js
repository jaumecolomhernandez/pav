var searchData=
[
  ['m',['m',['../classupc_1_1matrix.html#add034dcb2c5abd3d6a728da60f5590e9',1,'upc::matrix::m() const '],['../classupc_1_1matrix.html#a6b505e71e56088332a4203f6b6032dcf',1,'upc::matrix::m()']]],
  ['main',['main',['../get__pitch_8cpp.html#ac0f2228420376f4db7e1274f2b41667c',1,'main(int argc, const char *argv[]):&#160;get_pitch.cpp'],['../pitch__evaluate_8cpp.html#ac0f2228420376f4db7e1274f2b41667c',1,'main(int argc, const char *argv[]):&#160;pitch_evaluate.cpp'],['../test__fft_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;test_fft.cpp'],['../main__vad_8c.html#ac0f2228420376f4db7e1274f2b41667c',1,'main(int argc, const char *argv[]):&#160;main_vad.c']]],
  ['make',['make',['../classupc_1_1Directory.html#aa2f4f4351b856d193eae61ea647151d4',1,'upc::Directory']]],
  ['matrix',['matrix',['../classupc_1_1matrix.html#a908e2ae559167d0376d2b095116029ab',1,'upc::matrix::matrix(size_type nrow=0, size_type ncol=0)'],['../classupc_1_1matrix.html#aedb3ba241346dfac0655cf4b63715e7f',1,'upc::matrix::matrix(const _Myt &amp;o)']]]
];
