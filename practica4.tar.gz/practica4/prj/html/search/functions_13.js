var searchData=
[
  ['writewav_5fmono',['writewav_mono',['../wavfile__mono_8h.html#a43d41231f7fb07149e00c477727a8254',1,'writewav_mono(const std::string &amp;filename, unsigned int sampling_freq, const std::vector&lt; float &gt; &amp;x):&#160;wavfile_mono.h'],['../wavfile__mono_8cpp.html#a044fc29ca8222e16e340036e9b28c0e8',1,'writewav_mono(const string &amp;filename, unsigned int sampling_freq, const vector&lt; float &gt; &amp;x):&#160;wavfile_mono.cpp']]]
];
