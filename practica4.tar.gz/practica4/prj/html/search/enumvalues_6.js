var searchData=
[
  ['trigo_5fbd_5flimit',['TRIGO_BD_LIMIT',['../classffft_1_1FFTReal.html#a69a4ed5b7507683f5233ddbd34f0e1eea5b9b73ce99dfec1ae2f92dd0151fa07e',1,'ffft::FFTReal']]]
];
