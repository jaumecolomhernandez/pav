var searchData=
[
  ['ffft',['ffft',['../namespaceffft.html',1,'']]]
];
