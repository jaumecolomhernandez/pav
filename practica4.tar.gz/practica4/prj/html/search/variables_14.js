var searchData=
[
  ['window',['window',['../classupc_1_1PitchAnalyzer.html#aa9531a6af11904dca47a18cc22c4bcdd',1,'upc::PitchAnalyzer']]]
];
