var searchData=
[
  ['index',['index',['../classupc_1_1CircularIndex.html#a0d0973d1fc7fa4200ac39dc2880e0081',1,'upc::CircularIndex::index()'],['../classupc_1_1DigitalFilter.html#ae2b58018045cfca38cad387dd4b82e83',1,'upc::DigitalFilter::index()']]],
  ['interest',['interest',['../FFTReal__readme_8txt.html#a8dd124b3ee508be769f386edc2b8ccc7',1,'FFTReal_readme.txt']]]
];
