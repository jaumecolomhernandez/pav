var searchData=
[
  ['m',['m',['../classupc_1_1matrix.html#add034dcb2c5abd3d6a728da60f5590e9',1,'upc::matrix::m() const '],['../classupc_1_1matrix.html#a6b505e71e56088332a4203f6b6032dcf',1,'upc::matrix::m()']]],
  ['m_5fncol',['m_ncol',['../classupc_1_1matrix.html#a053950016358b76da92c0a25c01987e9',1,'upc::matrix']]],
  ['m_5fnrow',['m_nrow',['../classupc_1_1matrix.html#a2a32ddd89dd5b9c85d95498f9fb77c70',1,'upc::matrix']]],
  ['m_5fp',['m_p',['../classupc_1_1matrix.html#a01c5df069e0cddf9efcb5632a7e9c220',1,'upc::matrix']]],
  ['m_5fv',['m_v',['../classupc_1_1matrix.html#a1fd23b090b8e985c526d913792ad0f96',1,'upc::matrix']]],
  ['main',['main',['../get__pitch_8cpp.html#ac0f2228420376f4db7e1274f2b41667c',1,'main(int argc, const char *argv[]):&#160;get_pitch.cpp'],['../pitch__evaluate_8cpp.html#ac0f2228420376f4db7e1274f2b41667c',1,'main(int argc, const char *argv[]):&#160;pitch_evaluate.cpp'],['../test__fft_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;test_fft.cpp'],['../main__vad_8c.html#ac0f2228420376f4db7e1274f2b41667c',1,'main(int argc, const char *argv[]):&#160;main_vad.c']]],
  ['main_5fvad_2ec',['main_vad.c',['../main__vad_8c.html',1,'']]],
  ['make',['make',['../classupc_1_1Directory.html#aa2f4f4351b856d193eae61ea647151d4',1,'upc::Directory']]],
  ['matrix',['matrix',['../classupc_1_1matrix.html#a908e2ae559167d0376d2b095116029ab',1,'upc::matrix::matrix(size_type nrow=0, size_type ncol=0)'],['../classupc_1_1matrix.html#aedb3ba241346dfac0655cf4b63715e7f',1,'upc::matrix::matrix(const _Myt &amp;o)']]],
  ['matrix',['matrix',['../classupc_1_1matrix.html',1,'upc']]],
  ['matrix_2eh',['matrix.h',['../matrix_8h.html',1,'']]],
  ['max_5fbit_5fdepth',['MAX_BIT_DEPTH',['../classffft_1_1FFTReal.html#a39f5a2ec14c15f9198268500716e5dbaabec37ae38b07b6e3e1230562f01882a2',1,'ffft::FFTReal']]],
  ['max_5ff0',['MAX_F0',['../namespaceupc.html#ab69be42753266b6e1a0deaa8eba56a19',1,'upc']]],
  ['min_5ff0',['MIN_F0',['../namespaceupc.html#ae8ed4ce6dc2c05dfc1aa6432db41e1ae',1,'upc']]],
  ['mkdir',['MKDIR',['../filename_8cpp.html#a390bd49d566d1ac38c66b638e80127d7',1,'filename.cpp']]]
];
