var searchData=
[
  ['datatype',['DataType',['../classffft_1_1DynArray.html#aa21fa88c73e511acb18a7e778190ab02',1,'ffft::DynArray::DataType()'],['../classffft_1_1FFTReal.html#a606148f1cf8c3b7d705473932fc063d1',1,'ffft::FFTReal::DataType()'],['../classffft_1_1OscSinCos.html#af91237051e92ce0af7aaf38b1826244d',1,'ffft::OscSinCos::DataType()']]],
  ['debug_5fvad',['DEBUG_VAD',['../main__vad_8c.html#ada6204163b0b4cff6d248aaa88837230',1,'main_vad.c']]],
  ['def_2eh',['def.h',['../def_8h.html',1,'']]],
  ['digital_5ffilter_2ecpp',['digital_filter.cpp',['../digital__filter_8cpp.html',1,'']]],
  ['digital_5ffilter_2eh',['digital_filter.h',['../digital__filter_8h.html',1,'']]],
  ['digitalfilter',['DigitalFilter',['../classupc_1_1DigitalFilter.html',1,'upc']]],
  ['digitalfilter',['DigitalFilter',['../classupc_1_1DigitalFilter.html#a3d8e61b92170380d06b26aee1ebc1f16',1,'upc::DigitalFilter::DigitalFilter(const std::vector&lt; float &gt; &amp;_a, const std::vector&lt; float &gt; &amp;_b, float g=1.0F)'],['../classupc_1_1DigitalFilter.html#ac3c32e0d51a88354482f13528e9a7842',1,'upc::DigitalFilter::DigitalFilter()'],['../classupc_1_1DigitalFilter.html#a54937beb73f0789cb9265498522da628',1,'upc::DigitalFilter::DigitalFilter(const DigitalFilter &amp;f)']]],
  ['dir',['DIR',['../classupc_1_1FileInfo.html#a0d92d84fa1bd96c5e623e696ef484f38aaa05780e3df0257e7affc677909e2e2f',1,'upc::FileInfo']]],
  ['directory',['Directory',['../classupc_1_1Directory.html',1,'upc']]],
  ['directory',['Directory',['../classupc_1_1Directory.html#a2b40221a7578b439c262c66ba964f6c2',1,'upc::Directory::Directory()'],['../classupc_1_1Directory.html#a4b6321fb7644d3dcf225e2e666b837da',1,'upc::Directory::Directory(const Path &amp;p)'],['../classupc_1_1Directory.html#aca9acc226940f166429185989023727f',1,'upc::Directory::Directory(const string &amp;p)'],['../classupc_1_1Directory.html#afb8c8e0bc50664d8505e0fa392f99657',1,'upc::Directory::Directory(const char *p)']]],
  ['dmatrix',['dmatrix',['../namespaceupc.html#a53f2db863d6ef79ba43159171dce9612',1,'upc']]],
  ['do_5ffft',['do_fft',['../classffft_1_1FFTReal.html#a4c5b863a285c5a87f38517735cbf1352',1,'ffft::FFTReal::do_fft()'],['../FFTReal__readme_8txt.html#a601296d1e380b29c96683b649d7d1518',1,'do_fft():&#160;FFTReal_readme.txt']]],
  ['do_5fifft',['do_ifft',['../classffft_1_1FFTReal.html#a8ab2e0da482cea88a61f01d58c074989',1,'ffft::FFTReal::do_ifft()'],['../FFTReal__readme_8txt.html#a1a33a3b7245f269d5150c436da7d5ed6',1,'do_ifft():&#160;FFTReal_readme.txt']]],
  ['dvector',['dvector',['../namespaceupc.html#a226c72b20137fbf8cc10b0c0ca887b5d',1,'upc']]],
  ['dynarray',['DynArray',['../classffft_1_1DynArray.html#a3a1bc9474a3891360464c4ad97d846ff',1,'ffft::DynArray::DynArray()'],['../classffft_1_1DynArray.html#a26919351a30b4be36c3e3ee500a7c6a7',1,'ffft::DynArray::DynArray(long size)'],['../classffft_1_1DynArray.html#a7d28eb73cf75f2c669a32dde120eb2cb',1,'ffft::DynArray::DynArray(const DynArray &amp;other)']]],
  ['dynarray',['DynArray',['../classffft_1_1DynArray.html',1,'ffft']]],
  ['dynarray_2eh',['DynArray.h',['../DynArray_8h.html',1,'']]],
  ['dynarray_2ehpp',['DynArray.hpp',['../DynArray_8hpp.html',1,'']]],
  ['dynarray_3c_20datatype_20_3e',['DynArray&lt; DataType &gt;',['../classffft_1_1DynArray.html',1,'ffft']]],
  ['dynarray_3c_20ffft_3a_3aoscsincos_20_3e',['DynArray&lt; ffft::OscSinCos &gt;',['../classffft_1_1DynArray.html',1,'ffft']]],
  ['dynarray_3c_20long_20_3e',['DynArray&lt; long &gt;',['../classffft_1_1DynArray.html',1,'ffft']]]
];
