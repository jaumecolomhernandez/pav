var searchData=
[
  ['unvoiced',['unvoiced',['../classupc_1_1PitchAnalyzer.html#a0b32960107336078d87118cb10d6c83f',1,'upc::PitchAnalyzer']]],
  ['use_5fbuffer',['use_buffer',['../classffft_1_1FFTReal.html#af1fcd007f1cf0b41bd2188e0b3cd5cca',1,'ffft::FFTReal']]]
];
