var searchData=
[
  ['v',['v',['../classupc_1_1array.html#a160dca0372cf7ec405a44e6c43852381',1,'upc::array::v() const '],['../classupc_1_1array.html#a1b5e50b24d426dd6652139190c0d5b62',1,'upc::array::v()']]],
  ['vad',['vad',['../vad_8h.html#a4913b81eb5faf1d5bdc2d776272c3333',1,'vad(VAD_DATA *vad_data, float *x, double *silence_time, float *t_up, float *t_down):&#160;vad.c'],['../vad_8c.html#a4913b81eb5faf1d5bdc2d776272c3333',1,'vad(VAD_DATA *vad_data, float *x, double *silence_time, float *t_up, float *t_down):&#160;vad.c']]],
  ['vad_5fclose',['vad_close',['../vad_8h.html#ae03a22f498f04499bc665da5196aedf4',1,'vad_close(VAD_DATA *vad_data):&#160;vad.c'],['../vad_8c.html#ae03a22f498f04499bc665da5196aedf4',1,'vad_close(VAD_DATA *vad_data):&#160;vad.c']]],
  ['vad_5fframe_5fsize',['vad_frame_size',['../vad_8h.html#a03913fc4fc1a6f97dee805b6530c400b',1,'vad_frame_size(VAD_DATA *):&#160;vad.c'],['../vad_8c.html#a175d85bfe840f8bd5868a2f66facfc79',1,'vad_frame_size(VAD_DATA *vad_data):&#160;vad.c']]],
  ['vad_5fopen',['vad_open',['../vad_8h.html#ac24b4ee983693460003682c302be68c5',1,'vad_open(float sampling_rate):&#160;vad.c'],['../vad_8c.html#aa59349cef94e43aeda991f61a179927b',1,'vad_open(float rate):&#160;vad.c']]],
  ['vad_5fshow_5fstate',['vad_show_state',['../vad_8h.html#a18dc5ba22b3015351ec225f73517cdd3',1,'vad_show_state(const VAD_DATA *, FILE *):&#160;vad.c'],['../vad_8c.html#abbcd550d8ffab66eef3623974299f912',1,'vad_show_state(const VAD_DATA *vad_data, FILE *out):&#160;vad.c']]]
];
