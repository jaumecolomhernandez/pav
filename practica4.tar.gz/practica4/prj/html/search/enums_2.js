var searchData=
[
  ['window',['Window',['../classupc_1_1PitchAnalyzer.html#ab82b7694d6bc72839e5be6e526be81b6',1,'upc::PitchAnalyzer']]]
];
