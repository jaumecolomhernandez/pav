var searchData=
[
  ['fft_5fobject',['fft_object',['../FFTReal__readme_8txt.html#a38b2d99092edb3ec444550a95aa1951f',1,'FFTReal_readme.txt']]],
  ['fftreal',['FFTReal',['../classffft_1_1FFTReal.html#a627db4d781235302c3a229fc4d7a10ba',1,'ffft::FFTReal::FFTReal(long length)'],['../classffft_1_1FFTReal.html#abb05c7093d0c905e4c3b3e1285bee8a4',1,'ffft::FFTReal::FFTReal()'],['../classffft_1_1FFTReal.html#a9ad7353cb1205c00d77f69b9d3362ba3',1,'ffft::FFTReal::FFTReal(const FFTReal &amp;other)']]],
  ['fileinfo',['FileInfo',['../classupc_1_1FileInfo.html#aa6b799f8194d7426f79b79ec88458e77',1,'upc::FileInfo::FileInfo()'],['../namespaceupc.html#a4c5e814ef76fc815a67f0de482283ff5',1,'upc::fileInfo()']]],
  ['filename',['Filename',['../classupc_1_1Filename.html#ab3ba943521dc541e1eed8a3560d4c728',1,'upc::Filename::Filename()'],['../classupc_1_1Filename.html#a80bdd15a0d0da8cf97a59125c3cae2c9',1,'upc::Filename::Filename(const Path &amp;p)'],['../classupc_1_1Filename.html#a13e550c5b28bf991c84c053035760ed4',1,'upc::Filename::Filename(const string &amp;p)'],['../classupc_1_1Filename.html#a005b26738aa7db3b9f89258600b1e6f3',1,'upc::Filename::Filename(const char *p)']]],
  ['freqz',['freqz',['../classupc_1_1DigitalFilter.html#a81e5fab2bf8cbab0e70622b7fa2cfe91',1,'upc::DigitalFilter::freqz(std::vector&lt; float &gt; const freq, bool db=true) const '],['../classupc_1_1DigitalFilter.html#a580b4f2584d0b993e1fc6f9d9256b9f8',1,'upc::DigitalFilter::freqz(unsigned int N, bool db=true) const ']]]
];
