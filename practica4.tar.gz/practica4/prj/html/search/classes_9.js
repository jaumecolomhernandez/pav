var searchData=
[
  ['vad_5fdata',['VAD_DATA',['../structVAD__DATA.html',1,'']]]
];
