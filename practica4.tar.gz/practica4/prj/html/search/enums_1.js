var searchData=
[
  ['vad_5fstate',['VAD_STATE',['../vad_8h.html#a655a5d992101d81e27b861d90c712d65',1,'vad.h']]]
];
