var searchData=
[
  ['max_5fbit_5fdepth',['MAX_BIT_DEPTH',['../classffft_1_1FFTReal.html#a39f5a2ec14c15f9198268500716e5dbaabec37ae38b07b6e3e1230562f01882a2',1,'ffft::FFTReal']]]
];
