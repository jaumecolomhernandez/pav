var searchData=
[
  ['osctype',['OscType',['../classffft_1_1FFTReal.html#a3b9f6dae05435b3696c6c84155e0953a',1,'ffft::FFTReal']]]
];
