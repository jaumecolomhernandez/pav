var searchData=
[
  ['vstring',['vstring',['../namespaceupc.html#ab61343ef80507c505066d99a281645ee',1,'upc']]]
];
