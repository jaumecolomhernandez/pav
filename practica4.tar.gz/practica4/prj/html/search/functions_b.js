var searchData=
[
  ['ncol',['ncol',['../classupc_1_1matrix.html#a0e8f41d88948610215db9cc8eafa02a6',1,'upc::matrix']]],
  ['nrow',['nrow',['../classupc_1_1matrix.html#a7b922be25c0cf0d255252a4fe7350ea2',1,'upc::matrix']]]
];
