#!/bin/bash

#Compute model
#python create_features.py
#Calculate model
make -C ./prj all
#Evaluation
